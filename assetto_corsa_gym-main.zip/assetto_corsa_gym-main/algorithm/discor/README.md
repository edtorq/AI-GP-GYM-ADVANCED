# DisCor in PyTorch
This is a PyTorch implementation of DisCor[[1]](#references) and Soft Actor-Critic[[2,3]].


## Setup
If you are using Anaconda, first create the virtual environment.

```bash
conda create -n discor python=3.8 -y
conda activate discor
```

Then, you need to setup a MuJoCo license for your computer. Please follow the instruction in [mujoco-py](https://github.com/openai/mujoco-py
) for help.

You can install Python libraries using pip.

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### MetaWorld

```bash
python train.py --cuda --env_id hammer-v1 --config config/metaworld.yaml --num_steps 2000000 --algo discor
```

### Gym

```bash
python train.py --cuda --env_id Walker2d-v2 --config config/mujoco.yaml --algo discor
```