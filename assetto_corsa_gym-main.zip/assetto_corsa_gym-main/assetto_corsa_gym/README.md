Reference:
	assetto-corsa-autonomous-racing-plugin

# To install
pip install .

# Uninstall
pip uninstall assetto_corsa_gym